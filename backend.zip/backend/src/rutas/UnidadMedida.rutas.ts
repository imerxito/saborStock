import {Router} from "express";
import {UnidadMedidaControlador} from "../controladores/UnidadMedidaControlador.js";

const router= Router();
const unidadMedidaControlador= new UnidadMedidaControlador();

router.get("/",(req,res)=>unidadMedidaControlador.listar(req,res));
router.get("/:id",(req,res)=>unidadMedidaControlador.obtenerPorId(req,res));
router.post("/",(req,res)=>unidadMedidaControlador.crear(req,res));
router.put("/:id",(req,res)=>unidadMedidaControlador.actualizar(req,res));
router.patch("/:id/activar",(req,res)=>unidadMedidaControlador.activar(req,res));
router.patch("/:id/desactivar",(req,res)=>unidadMedidaControlador.desactivar(req,res));

export default router;