import React, { useState } from 'react';
import { 
  Lock, 
  Unlock, 
  Receipt, 
  ShoppingCart, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Users, 
  CreditCard, 
  DollarSign, 
  QrCode, 
  Plus, 
  Minus,
  Trash2, 
  CheckCircle,
  AlertCircle,
  Filter,
  Clock,
  Layers,
  Calendar,
  UserCheck,
  Eye
} from 'lucide-react';

// --- Tipos de Datos ---
type MetodoPago = 'efectivo' | 'transferencia' | 'tarjeta' | 'mixto';

interface Producto {
  id: string;
  nombre: string;
  precio: number;
  categoria: string;
}

interface ItemPedido {
  producto: Producto;
  cantidad: number;
}

interface Movimiento {
  id: string;
  tipo: 'ingreso' | 'egreso';
  concepto: string;
  monto: number;
  hora: string;
}

interface PagoNomina {
  id: string;
  empleado: string;
  cedula: string;
  telefono: string;
  cargo: string;
  montoBase: number;
  bono: number;
  montoTotal: number;
  metodo: string;
  fecha: string;
}

interface HistorialMesaItem {
  id: string;
  mesa: string;
  seccion: string;
  monto: number;
  mesero: string;
  metodoPago: string;
  estado: 'Pagada' | 'Cancelada' | 'En proceso';
  fechaApertura: string;
  fechaCierre: string;
  items: { nombre: string; cantidad: number; precio: number }[];
}

// Datos Mock
const CATEGORIAS = ['Todas', 'Comidas', 'Bebidas', 'Licores', 'Adicionales'];

const PRODUCTOS_MOCK: Producto[] = [
  { id: '1', nombre: 'Hamburguesa Especial', precio: 22000, categoria: 'Comidas' },
  { id: '2', nombre: 'Pizza Personal Peperoni', precio: 18000, categoria: 'Comidas' },
  { id: '3', nombre: 'Papas a la Francesa', precio: 8000, categoria: 'Comidas' },
  { id: '4', nombre: 'Cerveza Club Colombia', precio: 7000, categoria: 'Bebidas' },
  { id: '5', nombre: 'Limonada Cerezada', precio: 9000, categoria: 'Bebidas' },
  { id: '6', nombre: 'Aguardiente Antioqueño (Botella)', precio: 65000, categoria: 'Licores' },
  { id: '7', nombre: 'Salsa Extra BBQ', precio: 3000, categoria: 'Adicionales' },
];

const EMPLEADOS_MOCK = [
  { nombre: 'Carlos Gómez', cedula: '1065789123', telefono: '3001234567', cargo: 'Mesero' },
  { nombre: 'Ana María Pérez', cedula: '1065987456', telefono: '3109876543', cargo: 'Cajera' },
  { nombre: 'Luis Fernando Díaz', cedula: '1065412789', telefono: '3204567891', cargo: 'Chef' },
];

const HISTORIAL_MESAS_MOCK: HistorialMesaItem[] = [
  { id: 'HM-101', mesa: 'Mesa 1', seccion: 'Piscina', monto: 45000, mesero: 'Carlos Gómez', metodoPago: 'Efectivo', estado: 'Pagada', fechaApertura: '02/11/2026 - 01:30 PM', fechaCierre: '02/11/2026 - 02:40 PM', items: [{ nombre: 'Hamburguesa Especial', cantidad: 1, precio: 22000 }, { nombre: 'Limonada Cerezada', cantidad: 1, precio: 9000 }, { nombre: 'Papas a la Francesa', cantidad: 1, precio: 8000 }] },
  { id: 'HM-102', mesa: 'Mesa 4', seccion: 'Terraza', monto: 72000, mesero: 'Ana María Pérez', metodoPago: 'Transferencia', estado: 'Pagada', fechaApertura: '02/11/2026 - 02:15 PM', fechaCierre: '02/11/2026 - 03:10 PM', items: [{ nombre: 'Aguardiente Antioqueño (Botella)', cantidad: 1, precio: 65000 }, { nombre: 'Cerveza Club Colombia', cantidad: 1, precio: 7000 }] },
  { id: 'HM-103', mesa: 'Mesa 2', seccion: 'Piscina', monto: 18000, mesero: 'Carlos Gómez', metodoPago: 'N/A', estado: 'Cancelada', fechaApertura: '02/11/2026 - 03:00 PM', fechaCierre: '02/11/2026 - 03:15 PM', items: [{ nombre: 'Pizza Personal Peperoni', cantidad: 1, precio: 18000 }] },
  { id: 'HM-104', mesa: 'Mesa 6', seccion: 'VIP', monto: 125000, mesero: 'Luis Fernando Díaz', metodoPago: 'Tarjeta', estado: 'Pagada', fechaApertura: '02/11/2026 - 03:30 PM', fechaCierre: '02/11/2026 - 05:00 PM', items: [{ nombre: 'Hamburguesa Especial', cantidad: 3, precio: 22000 }, { nombre: 'Limonada Cerezada', cantidad: 3, precio: 9000 }, { nombre: 'Aguardiente Antioqueño (Botella)', cantidad: 1, precio: 32000 }] },
  { id: 'HM-105', mesa: 'Mesa 3', seccion: 'Terraza', monto: 35000, mesero: 'Carlos Gómez', metodoPago: 'Mixto', estado: 'Pagada', fechaApertura: '02/11/2026 - 04:10 PM', fechaCierre: '02/11/2026 - 05:20 PM', items: [{ nombre: 'Pizza Personal Peperoni', cantidad: 1, precio: 18000 }, { nombre: 'Cerveza Club Colombia', cantidad: 2, precio: 7000 }] },
];

export default function CajaPage() {
  const [turnoAbierto, setTurnoAbierto] = useState<boolean>(true);
  const [baseInicial, setBaseInicial] = useState<number>(150000);
  const [activeTab, setActiveTab] = useState<'ventas' | 'cobrar' | 'historialMesas' | 'movimientos' | 'nomina'>('ventas');

  // Venta Directa
  const [categoriaSeleccionada, setCategoriaSeleccionada] = useState<string>('Todas');
  const [carrito, setCarrito] = useState<ItemPedido[]>([]);
  const [nombreCliente, setNombreCliente] = useState('');

  // Cobro de Facturas
  const [mesasActivas, setMesasActivas] = useState([
    { id: 'm3', nombre: 'Mesa 3', seccion: 'Piscina', total: 45000, items: [{ nombre: 'Cerveza Club Colombia', cantidad: 1, precio: 7000 }, { nombre: 'Pizza Personal Peperoni', cantidad: 1, precio: 18000 }] },
    { id: 'm5', nombre: 'Mesa 5', seccion: 'Terraza', total: 82000, items: [{ nombre: 'Hamburguesa Especial', cantidad: 2, precio: 22000 }] }
  ]);
  const [mesaSeleccionadaId, setMesaSeleccionadaId] = useState<string>('m3');
  const [metodoPago, setMetodoPago] = useState<MetodoPago>('efectivo');
  const [montoEfectivo, setMontoEfectivo] = useState<number>(0);
  const [montoDigital, setMontoDigital] = useState<number>(0);

  // Historial de Mesas (Modal de Detalle)
  const [mesaDetalleModal, setMesaDetalleModal] = useState<HistorialMesaItem | null>(null);

  // Ingresos / Egresos
  const [movimientos, setMovimientos] = useState<Movimiento[]>([
    { id: '1', tipo: 'ingreso', concepto: 'Base inicial de caja', monto: 150000, hora: '08:00 AM' },
    { id: '2', tipo: 'egreso', concepto: 'Compra hielo adicional', monto: 12000, hora: '10:30 AM' },
  ]);
  const [nuevoMovTipo, setNuevoMovTipo] = useState<'ingreso' | 'egreso'>('ingreso');
  const [nuevoMovConcepto, setNuevoMovConcepto] = useState('');
  const [nuevoMovMonto, setNuevoMovMonto] = useState('');

  // Nómina
  const [nominas, setNominas] = useState<PagoNomina[]>([
    { id: '1', empleado: 'Carlos Gómez', cedula: '1065789123', telefono: '3001234567', cargo: 'Mesero', montoBase: 50000, bono: 10000, montoTotal: 60000, metodo: 'Efectivo', fecha: 'Hoy' }
  ]);
  const [empleadoSeleccionado, setEmpleadoSeleccionado] = useState(EMPLEADOS_MOCK[0]);
  const [nomBono, setNomBono] = useState<number>(0);
  const [nomBase, setNomBase] = useState<number>(50000);

  // Handlers Carrito
  const agregarAlCarrito = (prod: Producto) => {
    setCarrito(prev => {
      const existe = prev.find(item => item.producto.id === prod.id);
      if (existe) {
        return prev.map(item =>
          item.producto.id === prod.id ? { ...item, cantidad: item.cantidad + 1 } : item
        );
      }
      return [...prev, { producto: prod, cantidad: 1 }];
    });
  };

  const actualizarCantidadItem = (id: string, nuevaCantidad: number) => {
    if (nuevaCantidad <= 0) {
      setCarrito(prev => prev.filter(item => item.producto.id !== id));
    } else {
      setCarrito(prev => prev.map(item => 
        item.producto.id === id ? { ...item, cantidad: nuevaCantidad } : item
      ));
    }
  };

  const totalCarrito = carrito.reduce((acc, item) => acc + item.producto.precio * item.cantidad, 0);
  const mesaActual = mesasActivas.find(m => m.id === mesaSeleccionadaId) || mesasActivas[0];

  const cobrarMesa = () => {
    if (!mesaActual) return;
    const nuevoMov: Movimiento = {
      id: Date.now().toString(),
      tipo: 'ingreso',
      concepto: `Cobro de factura ${mesaActual.nombre} (${mesaActual.seccion})`,
      monto: mesaActual.total,
      hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setMovimientos([nuevoMov, ...movimientos]);
    setMesasActivas(prev => prev.filter(m => m.id !== mesaActual.id));
    if (mesasActivas.length > 1) {
      const restante = mesasActivas.filter(m => m.id !== mesaActual.id);
      setMesaSeleccionadaId(restante[0].id);
    }
  };

  const registrarMovimiento = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nuevoMovConcepto || !nuevoMovMonto) return;
    const nuevo: Movimiento = {
      id: Date.now().toString(),
      tipo: nuevoMovTipo,
      concepto: nuevoMovConcepto,
      monto: parseFloat(nuevoMovMonto),
      hora: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setMovimientos([nuevo, ...movimientos]);
    setNuevoMovConcepto('');
    setNuevoMovMonto('');
  };

  const registrarNomina = (e: React.FormEvent) => {
    e.preventDefault();
    if (!empleadoSeleccionado) return;
    const total = Number(nomBase) + Number(nomBono);
    const nueva: PagoNomina = {
      id: Date.now().toString(),
      empleado: empleadoSeleccionado.nombre,
      cedula: empleadoSeleccionado.cedula,
      telefono: empleadoSeleccionado.telefono,
      cargo: empleadoSeleccionado.cargo,
      montoBase: Number(nomBase),
      bono: Number(nomBono),
      montoTotal: total,
      metodo: 'Efectivo',
      fecha: new Date().toLocaleDateString()
    };
    setNominas([nueva, ...nominas]);
    setNomBono(0);
  };

  return (
    <div className="min-h-screen bg-[#081318] text-slate-100 p-4 sm:p-6 font-sans">
      
      {/* HEADER DE CAJA (Mantiene el mismo fondo que la app) */}
      <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 pb-4 border-b border-[#16353e]">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <DollarSign className="text-emerald-400" /> Control de Caja y Turnos
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">Gestión de facturación, comandeo rápido y flujo de efectivo.</p>
        </div>

        {/* Indicador de Turno Compacto */}
        <div className="flex items-center gap-3 bg-[#081318] px-3 py-1.5 rounded-lg border border-[#16353e]">
          <div className="flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${turnoAbierto ? 'bg-emerald-500 animate-pulse' : 'bg-[#ef4444]'}`} />
            <span className="text-xs font-medium">{turnoAbierto ? 'Turno Abierto' : 'Turno Cerrado'}</span>
          </div>
          <button
            onClick={() => setTurnoAbierto(!turnoAbierto)}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-semibold text-xs transition-all ${
              turnoAbierto 
                ? 'bg-[#ef4444]/10 text-[#ef4444] border border-[#ef4444]/30 hover:bg-[#ef4444]/20' 
                : 'bg-emerald-500 text-slate-950 hover:bg-emerald-400'
            }`}
          >
            {turnoAbierto ? <Lock size={14} /> : <Unlock size={14} />}
            {turnoAbierto ? 'Cerrar' : 'Abrir'}
          </button>
        </div>
      </header>

      {!turnoAbierto ? (
        <div className="bg-[#0e2229] border border-[#16353e] rounded-2xl p-8 sm:p-12 text-center max-w-md mx-auto mt-12">
          <AlertCircle className="mx-auto text-amber-400 mb-4" size={40} />
          <h2 className="text-lg font-bold text-white mb-2">La caja se encuentra cerrada</h2>
          <p className="text-slate-400 text-xs sm:text-sm mb-6">Debes abrir un turno e ingresar la base inicial para empezar a operar.</p>
          <div className="flex flex-col gap-3">
            <input 
              type="number" 
              placeholder="Base inicial ($)"
              value={baseInicial}
              onChange={(e) => setBaseInicial(Number(e.target.value))}
              className="bg-[#081318] border border-[#16353e] px-4 py-2 rounded-lg text-center text-white text-sm focus:outline-none focus:border-emerald-500"
            />
            <button 
              onClick={() => setTurnoAbierto(true)}
              className="bg-emerald-500 text-slate-950 font-bold py-2 rounded-lg text-sm hover:bg-emerald-400"
            >
              Iniciar Turno
            </button>
          </div>
        </div>
      ) : (
        <>
          {/* NAVEGACIÓN POR PESTAÑAS (TABS RESPONSIVO) */}
          <div className="flex gap-2 border-b border-[#16353e] mb-6 overflow-x-auto pb-1 scrollbar-thin">
            {[
              { id: 'ventas', label: 'Venta Directa', icon: ShoppingCart },
              { id: 'cobrar', label: 'Cobrar Mesas', icon: Receipt },
              { id: 'historialMesas', label: 'Historial Mesas', icon: Clock },
              { id: 'movimientos', label: 'Ingresos / Egresos', icon: ArrowUpRight },
              { id: 'nomina', label: 'Nómina & Bonos', icon: Users },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2.5 font-semibold text-xs sm:text-sm rounded-t-xl transition-all border-b-2 whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'border-emerald-400 bg-[#0e2229] text-emerald-400'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-[#0e2229]/50'
                }`}
              >
                <tab.icon size={16} /> {tab.label}
              </button>
            ))}
          </div>

          {/* TAB 1: VENTA DIRECTA */}
          {activeTab === 'ventas' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 bg-[#0e2229] p-4 sm:p-5 rounded-2xl border border-[#16353e]">
                <div className="flex items-center gap-2 mb-4">
                  <Layers size={18} className="text-emerald-400" />
                  <h3 className="text-base sm:text-lg font-bold text-white">Menú Rápido de Productos</h3>
                </div>

                <div className="flex gap-2 overflow-x-auto pb-3 mb-4 border-b border-[#16353e]">
                  {CATEGORIAS.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setCategoriaSeleccionada(cat)}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                        categoriaSeleccionada === cat
                          ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                          : 'bg-[#081318] text-slate-300 border border-[#16353e] hover:border-emerald-500/50'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-[420px] overflow-y-auto pr-1">
                  {PRODUCTOS_MOCK.filter(p => categoriaSeleccionada === 'Todas' || p.categoria === categoriaSeleccionada).map((prod) => (
                    <button
                      key={prod.id}
                      onClick={() => agregarAlCarrito(prod)}
                      className="bg-[#081318] border border-[#16353e] hover:border-emerald-500 p-3.5 rounded-xl text-left transition-all flex flex-col justify-between group shadow-sm"
                    >
                      <div>
                        <span className="text-[10px] text-emerald-400 font-semibold uppercase">{prod.categoria}</span>
                        <span className="block font-medium text-slate-200 group-hover:text-white mt-1 text-xs sm:text-sm">{prod.nombre}</span>
                      </div>
                      <span className="text-emerald-400 font-bold mt-3 text-sm sm:text-base">${prod.precio.toLocaleString()}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-[#0e2229] p-4 sm:p-5 rounded-2xl border border-[#16353e] flex flex-col justify-between">
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-white mb-3">Comanda Rápida (Sin Mesa)</h3>
                  <input
                    type="text"
                    placeholder="Nombre del Cliente / Barra"
                    value={nombreCliente}
                    onChange={(e) => setNombreCliente(e.target.value)}
                    className="w-full bg-[#081318] border border-[#16353e] px-3 py-2 rounded-lg text-xs sm:text-sm text-slate-200 mb-4 focus:outline-none focus:border-emerald-500"
                  />
                  <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                    {carrito.length === 0 ? (
                      <div className="text-center py-10">
                        <ShoppingCart className="mx-auto text-slate-600 mb-2" size={28} />
                        <p className="text-slate-400 text-xs sm:text-sm">El carrito está vacío</p>
                      </div>
                    ) : (
                      carrito.map((item) => (
                        <div key={item.producto.id} className="bg-[#081318] p-3 rounded-xl border border-[#16353e] flex flex-col gap-2">
                          <div className="flex justify-between items-start">
                            <span className="text-xs sm:text-sm font-medium text-slate-200">{item.producto.nombre}</span>
                            <span className="font-bold text-emerald-400 text-xs sm:text-sm">${(item.producto.precio * item.cantidad).toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-[11px] text-slate-400">${item.producto.precio.toLocaleString()} c/u</span>
                            
                            <div className="flex items-center gap-1.5 bg-[#0e2229] px-2 py-1 rounded-lg border border-[#16353e]">
                              <button 
                                onClick={() => actualizarCantidadItem(item.producto.id, item.cantidad - 1)}
                                className="text-slate-400 hover:text-white p-1"
                              >
                                <Minus size={12} />
                              </button>
                              <input 
                                type="number" 
                                min="1"
                                value={item.cantidad}
                                onChange={(e) => actualizarCantidadItem(item.producto.id, parseInt(e.target.value) || 0)}
                                className="w-8 bg-transparent text-center text-xs text-white font-bold focus:outline-none"
                              />
                              <button 
                                onClick={() => actualizarCantidadItem(item.producto.id, item.cantidad + 1)}
                                className="text-slate-400 hover:text-white p-1"
                              >
                                <Plus size={12} />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div className="border-t border-[#16353e] pt-4 mt-4">
                  <div className="flex justify-between items-center mb-4 text-base sm:text-lg font-bold">
                    <span>Total:</span>
                    <span className="text-emerald-400">${totalCarrito.toLocaleString()}</span>
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => setCarrito([])}
                      disabled={carrito.length === 0}
                      className="px-3 py-2 bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded-xl hover:bg-rose-500/20 disabled:opacity-50"
                    >
                      <Trash2 size={16} />
                    </button>
                    <button 
                      disabled={carrito.length === 0}
                      onClick={() => {
                        alert('¡Comanda enviada y registrada en caja!');
                        setCarrito([]);
                      }}
                      className="flex-1 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-bold py-2.5 rounded-xl text-xs sm:text-sm transition-all shadow-lg shadow-emerald-500/20"
                    >
                      Cobrar / Enviar Comanda
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: COBRAR MESAS */}
          {activeTab === 'cobrar' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 bg-[#0e2229] p-4 sm:p-5 rounded-2xl border border-[#16353e]">
                <h3 className="text-base sm:text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <Filter size={18} className="text-emerald-400" /> Mesas Ocupadas Listas para Cobrar
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {mesasActivas.length === 0 ? (
                    <p className="text-slate-500 text-sm col-span-2 text-center py-12">No hay mesas ocupadas en este momento.</p>
                  ) : (
                    mesasActivas.map((m) => {
                      const seleccionada = m.id === mesaSeleccionadaId;
                      return (
                        <div
                          key={m.id}
                          onClick={() => setMesaSeleccionadaId(m.id)}
                          className={`cursor-pointer p-4 rounded-xl border transition-all flex flex-col justify-between ${
                            seleccionada 
                              ? 'bg-emerald-500/10 border-emerald-500 shadow-lg' 
                              : 'bg-[#081318] border-[#16353e] hover:border-slate-600'
                          }`}
                        >
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <span className="font-bold text-white text-base">{m.nombre}</span>
                              <span className="block text-xs text-slate-400">Sección: {m.seccion}</span>
                            </div>
                            <span className="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 text-xs font-semibold">Ocupada</span>
                          </div>
                          <div className="flex justify-between items-center mt-3 pt-2 border-t border-[#16353e]">
                            <span className="text-xs text-slate-400">{m.items.length} productos</span>
                            <span className="font-bold text-emerald-400">${m.total.toLocaleString()}</span>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              <div className="bg-[#0e2229] p-4 sm:p-5 rounded-2xl border border-[#16353e] flex flex-col justify-between">
                {mesasActivas.length > 0 && mesaActual ? (
                  <div>
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-base sm:text-lg font-bold text-white">Cobrar {mesaActual.nombre}</h3>
                      <span className="text-xs px-2 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 font-bold">${mesaActual.total.toLocaleString()}</span>
                    </div>

                    <div className="bg-[#081318] p-3 rounded-xl border border-[#16353e] space-y-1.5 mb-4 max-h-36 overflow-y-auto">
                      {mesaActual.items.map((it, idx) => (
                        <div key={idx} className="flex justify-between text-xs text-slate-300">
                          <span>{it.cantidad}x {it.nombre}</span>
                          <span className="text-slate-400">${(it.precio * it.cantidad).toLocaleString()}</span>
                        </div>
                      ))}
                    </div>

                    <label className="text-xs text-slate-400 mb-2 block">Método de Pago</label>
                    <div className="grid grid-cols-2 gap-2 mb-4">
                      {[
                        { id: 'efectivo', label: 'Efectivo', icon: DollarSign },
                        { id: 'transferencia', label: 'Transferencia', icon: QrCode },
                        { id: 'tarjeta', label: 'Tarjeta', icon: CreditCard },
                        { id: 'mixto', label: 'Mixto', icon: Receipt },
                      ].map(m => (
                        <button
                          key={m.id}
                          onClick={() => setMetodoPago(m.id as MetodoPago)}
                          className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-semibold transition-all ${
                            metodoPago === m.id 
                              ? 'bg-emerald-500/10 border-emerald-500 text-emerald-400' 
                              : 'bg-[#081318] border-[#16353e] text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          <m.icon size={14} /> {m.label}
                        </button>
                      ))}
                    </div>

                    {metodoPago === 'mixto' && (
                      <div className="space-y-2 bg-[#081318] p-3 rounded-xl border border-[#16353e] mb-4">
                        <div>
                          <label className="text-[10px] text-slate-400">Efectivo</label>
                          <input type="number" placeholder="$0" value={montoEfectivo || ''} onChange={(e) => setMontoEfectivo(Number(e.target.value))} className="w-full bg-[#0e2229] border border-[#16353e] px-2.5 py-1 rounded-lg text-xs text-white" />
                        </div>
                        <div>
                          <label className="text-[10px] text-slate-400">Transferencia / Tarjeta</label>
                          <input type="number" placeholder="$0" value={montoDigital || ''} onChange={(e) => setMontoDigital(Number(e.target.value))} className="w-full bg-[#0e2229] border border-[#16353e] px-2.5 py-1 rounded-lg text-xs text-white" />
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-slate-500 text-sm text-center py-12">Selecciona una mesa disponible para cobrar.</p>
                )}

                <button 
                  disabled={mesasActivas.length === 0}
                  onClick={cobrarMesa}
                  className="w-full bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-bold py-3 rounded-xl text-xs sm:text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20"
                >
                  <CheckCircle size={16} /> Confirmar Facturación y Registrar Ingreso
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: HISTORIAL DE MESAS (TABLA FIJA Y ESTABLE) */}
          {activeTab === 'historialMesas' && (
            <div className="bg-[#0e2229] p-4 sm:p-6 rounded-2xl border border-[#16353e] flex flex-col h-[560px]">
              <div className="flex justify-between items-center mb-4 shrink-0">
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                    <Calendar className="text-cyan-400" size={20} /> Historial General de Mesas
                  </h3>
                  <p className="text-xs text-slate-400">Registro histórico de pedidos por mesa, estado y mesero a cargo.</p>
                </div>
              </div>

              {/* Contenedor Fijo para Tabla con Scroll Interno */}
              <div className="flex-1 overflow-x-auto overflow-y-auto border border-[#16353e] rounded-xl bg-[#081318]">
                <table className="w-full text-left border-collapse min-w-[700px]">
                  <thead className="sticky top-0 bg-[#0e2229] border-b border-[#16353e] text-xs font-semibold text-slate-400 uppercase tracking-wider z-10">
                    <tr>
                      <th className="py-3 px-4">Mesa</th>
                      <th className="py-3 px-4">Sección</th>
                      <th className="py-3 px-4">Mesero</th>
                      <th className="py-3 px-4">Apertura / Cierre</th>
                      <th className="py-3 px-4">Método</th>
                      <th className="py-3 px-4">Estado</th>
                      <th className="py-3 px-4 text-right">Total</th>
                      <th className="py-3 px-4 text-center">Detalle</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#16353e]/60 text-xs sm:text-sm text-slate-200">
                    {HISTORIAL_MESAS_MOCK.map((hm) => (
                      <tr key={hm.id} className="hover:bg-[#0e2229]/60 transition-colors">
                        <td className="py-3 px-4 font-bold text-white">{hm.mesa}</td>
                        <td className="py-3 px-4 text-slate-400">{hm.seccion}</td>
                        <td className="py-3 px-4 font-medium">{hm.mesero}</td>
                        <td className="py-3 px-4 text-slate-400 text-xs">
                          <div>{hm.fechaApertura}</div>
                          <div className="text-[10px] text-slate-500">Fin: {hm.fechaCierre}</div>
                        </td>
                        <td className="py-3 px-4">{hm.metodoPago}</td>
                        <td className="py-3 px-4">
                          <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
                            hm.estado === 'Pagada' 
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                              : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                          }`}>
                            {hm.estado}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right font-bold text-emerald-400">${hm.monto.toLocaleString()}</td>
                        <td className="py-3 px-4 text-center">
                          <button 
                            onClick={() => setMesaDetalleModal(hm)}
                            className="p-1.5 bg-[#16353e] hover:bg-[#1f4754] text-cyan-400 rounded-lg transition-all"
                            title="Ver Productos Pedidos"
                          >
                            <Eye size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 4: INGRESOS Y EGRESOS */}
          {activeTab === 'movimientos' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="bg-[#0e2229] p-4 sm:p-5 rounded-2xl border border-[#16353e] h-fit">
                <h3 className="text-base sm:text-lg font-bold text-white mb-4">Registrar Movimiento</h3>
                <form onSubmit={registrarMovimiento} className="space-y-4">
                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Tipo de Movimiento</label>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setNuevoMovTipo('ingreso')}
                        className={`flex-1 py-2 rounded-lg text-xs font-bold border transition-all flex items-center justify-center gap-1 ${
                          nuevoMovTipo === 'ingreso' ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400' : 'bg-[#081318] border-[#16353e] text-slate-400'
                        }`}
                      >
                        <ArrowDownLeft size={14} /> Ingreso
                      </button>
                      <button
                        type="button"
                        onClick={() => setNuevoMovTipo('egreso')}
                        className={`flex-1 py-2 rounded-lg text-xs font-bold border transition-all flex items-center justify-center gap-1 ${
                          nuevoMovTipo === 'egreso' ? 'bg-rose-500/20 border-rose-500 text-rose-400' : 'bg-[#081318] border-[#16353e] text-slate-400'
                        }`}
                      >
                        <ArrowUpRight size={14} /> Egreso
                      </button>
                    </div>
                  </div>

                  {nuevoMovTipo === 'egreso' && (
                    <div>
                      <label className="text-[11px] text-slate-400 mb-1 block">Casos comunes</label>
                      <div className="flex flex-wrap gap-1.5 mb-2">
                        {[
                          'Error del mesero', 
                          'El cliente no lo quiso', 
                          'Percance / Plato averiado', 
                          'Cortesía de la casa'
                        ].map(caso => (
                          <button
                            key={caso}
                            type="button"
                            onClick={() => setNuevoMovConcepto(caso)}
                            className="text-[11px] bg-[#081318] border border-[#16353e] hover:border-rose-500/50 text-slate-300 px-2.5 py-1 rounded-lg"
                          >
                            {caso}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Concepto / Motivo</label>
                    <input
                      type="text"
                      placeholder="Ej: Error del mesero o pago proveedor"
                      value={nuevoMovConcepto}
                      onChange={(e) => setNuevoMovConcepto(e.target.value)}
                      className="w-full bg-[#081318] border border-[#16353e] px-3 py-2 rounded-lg text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Monto ($)</label>
                    <input
                      type="number"
                      placeholder="0"
                      value={nuevoMovMonto}
                      onChange={(e) => setNuevoMovMonto(e.target.value)}
                      className="w-full bg-[#081318] border border-[#16353e] px-3 py-2 rounded-lg text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  <button type="submit" className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-2 rounded-lg text-xs sm:text-sm transition-all">
                    Guardar Movimiento
                  </button>
                </form>
              </div>

              <div className="lg:col-span-2 bg-[#0e2229] p-4 sm:p-5 rounded-2xl border border-[#16353e]">
                <h3 className="text-base sm:text-lg font-bold text-white mb-4">Historial de Flujo de Caja</h3>
                <div className="space-y-2 max-h-[450px] overflow-y-auto pr-1">
                  {movimientos.map((m) => (
                    <div key={m.id} className="flex justify-between items-center p-3 rounded-xl bg-[#081318] border border-[#16353e]">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${m.tipo === 'ingreso' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                          {m.tipo === 'ingreso' ? <ArrowDownLeft size={16} /> : <ArrowUpRight size={16} />}
                        </div>
                        <div>
                          <p className="text-xs sm:text-sm font-semibold text-slate-200">{m.concepto}</p>
                          <p className="text-[11px] text-slate-400">{m.hora}</p>
                        </div>
                      </div>
                      <span className={`font-bold text-xs sm:text-sm ${m.tipo === 'ingreso' ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {m.tipo === 'ingreso' ? '+' : '-'}${m.monto.toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: NÓMINA */}
          {activeTab === 'nomina' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="bg-[#0e2229] p-4 sm:p-5 rounded-2xl border border-[#16353e] h-fit">
                <h3 className="text-base sm:text-lg font-bold text-white mb-4">Pago de Nómina con Bono</h3>
                <form onSubmit={registrarNomina} className="space-y-4">
                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Seleccionar Empleado</label>
                    <select
                      onChange={(e) => {
                        const emp = EMPLEADOS_MOCK.find(item => item.nombre === e.target.value);
                        if (emp) setEmpleadoSeleccionado(emp);
                      }}
                      className="w-full bg-[#081318] border border-[#16353e] px-3 py-2 rounded-lg text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-emerald-500"
                    >
                      {EMPLEADOS_MOCK.map(emp => (
                        <option key={emp.cedula} value={emp.nombre}>{emp.nombre} - {emp.cargo}</option>
                      ))}
                    </select>
                  </div>

                  <div className="bg-[#081318] p-3 rounded-xl border border-[#16353e] space-y-1 text-xs text-slate-300">
                    <p className="flex items-center gap-1.5 font-bold text-emerald-400">
                      <UserCheck size={14} /> {empleadoSeleccionado.nombre}
                    </p>
                    <p className="text-slate-400">Cédula: <span className="text-slate-200">{empleadoSeleccionado.cedula}</span></p>
                    <p className="text-slate-400">Teléfono: <span className="text-slate-200">{empleadoSeleccionado.telefono}</span></p>
                    <p className="text-slate-400">Cargo: <span className="text-slate-200">{empleadoSeleccionado.cargo}</span></p>
                  </div>

                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Sueldo Base ($)</label>
                    <input
                      type="number"
                      value={nomBase}
                      onChange={(e) => setNomBase(Number(e.target.value))}
                      className="w-full bg-[#081318] border border-[#16353e] px-3 py-2 rounded-lg text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Bono / Incentivo ($)</label>
                    <input
                      type="number"
                      placeholder="0"
                      value={nomBono || ''}
                      onChange={(e) => setNomBono(Number(e.target.value))}
                      className="w-full bg-[#081318] border border-[#16353e] px-3 py-2 rounded-lg text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex justify-between items-center text-sm font-bold text-emerald-400">
                    <span>Total a Pagar:</span>
                    <span>${(Number(nomBase) + Number(nomBono)).toLocaleString()}</span>
                  </div>

                  <button type="submit" className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-2.5 rounded-lg text-xs sm:text-sm transition-all flex items-center justify-center gap-2">
                    <Plus size={16} /> Registrar Pago de Nómina
                  </button>
                </form>
              </div>

              <div className="lg:col-span-2 bg-[#0e2229] p-4 sm:p-5 rounded-2xl border border-[#16353e]">
                <h3 className="text-base sm:text-lg font-bold text-white mb-4">Pagos de Personal Registrados</h3>
                <div className="space-y-2 max-h-[450px] overflow-y-auto pr-1">
                  {nominas.map((n) => (
                    <div key={n.id} className="flex justify-between items-center p-3.5 rounded-xl bg-[#081318] border border-[#16353e]">
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-400">
                          <Users size={18} />
                        </div>
                        <div>
                          <p className="text-xs sm:text-sm font-semibold text-slate-200">{n.empleado} <span className="text-xs text-slate-400 font-normal">({n.cedula})</span></p>
                          <p className="text-[11px] text-slate-400">{n.cargo} • Tel: {n.telefono} • Base: ${n.montoBase.toLocaleString()} + Bono: ${n.bono.toLocaleString()}</p>
                        </div>
                      </div>
                      <span className="font-bold text-emerald-400 text-xs sm:text-sm">${n.montoTotal.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* MODAL VER PRODUCTOS DE MESA EN HISTORIAL */}
          {mesaDetalleModal && (
            <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50">
              <div className="bg-[#0e2229] border border-[#16353e] rounded-2xl max-w-md w-full p-6 shadow-2xl">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-base font-bold text-white">Consumo de {mesaDetalleModal.mesa} ({mesaDetalleModal.seccion})</h3>
                  <button onClick={() => setMesaDetalleModal(null)} className="text-slate-400 hover:text-white font-bold">✕</button>
                </div>

                <div className="space-y-2 bg-[#081318] p-4 rounded-xl border border-[#16353e] mb-4 max-h-60 overflow-y-auto">
                  {mesaDetalleModal.items.map((it, idx) => (
                    <div key={idx} className="flex justify-between text-xs text-slate-300 pb-2 border-b border-[#16353e]/40 last:border-0">
                      <span>{it.cantidad}x {it.nombre}</span>
                      <span className="font-semibold text-emerald-400">${(it.precio * it.cantidad).toLocaleString()}</span>
                    </div>
                  ))}
                </div>

                <div className="flex justify-between items-center text-sm font-bold text-white mb-4">
                  <span>Total Consumido:</span>
                  <span className="text-emerald-400">${mesaDetalleModal.monto.toLocaleString()}</span>
                </div>

                <button 
                  onClick={() => setMesaDetalleModal(null)}
                  className="w-full bg-[#16353e] hover:bg-[#1f4754] text-white py-2 rounded-xl text-xs font-bold transition-all"
                >
                  Cerrar
                </button>
              </div>
            </div>
          )}

        </>
      )}
    </div>
  );
}